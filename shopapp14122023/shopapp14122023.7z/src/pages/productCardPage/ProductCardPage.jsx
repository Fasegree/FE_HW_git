import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Rating from "../../components/Rating/Rating";
import s from './ProductCardPage.module.css'

export default function ProductCartPage(){
    const [product, setProducts] = useState({})
   const {id} = useParams()
   
    useEffect(()=>{
        fetch('https://fakestoreapi.com/products/'+id)
                .then(res => res.json())
                .then(data =>setProducts(()=>data))
              
    },[])
    console.log(product);
    return(
        <div>
            <img src={product.image}/>
           {product.title}
           <Rating className={s.rating} ratingValue={product.rating?.rate}/>
               <button onClick={-1}>Back</button>
        </div>
    )
}